class ComplexCore(PythonPlugin):
    def onEnable(self):
        self.getLogger().info("Hallo Welt!")